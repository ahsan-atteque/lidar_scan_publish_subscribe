from setuptools import setup
import os
from glob import glob

package_name = 'rplidar_s2_driver'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # Launch and config files must be installed explicitly for
        # ament_python packages -- unlike ament_cmake, there is no
        # automatic directory install.
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*launch.py')),
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
    ],
    install_requires=['setuptools', 'pyserial'],
    zip_safe=True,
    maintainer='Ahsan',
    maintainer_email='ahsan@example.com',
    description='Pure-Python ROS 2 driver for the SLAMTEC RPLIDAR S2.',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            's2_node = rplidar_s2_driver.s2_node:main',
        ],
    },
)
